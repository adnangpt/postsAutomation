# AutoMarketer Project Structure

## Complete File Tree

```
automarketer/
├── .env                              # Environment variables (DO NOT COMMIT)
├── .env.example                      # Environment variables template
├── .gitignore                        # Git ignore rules
├── jsconfig.json                     # JavaScript configuration
├── next.config.js                    # Next.js configuration
├── package.json                      # Project dependencies
├── package-lock.json                 # Locked dependencies
├── postcss.config.js                 # PostCSS configuration
├── tailwind.config.js                # Tailwind CSS configuration
├── README.md                         # Main documentation
├── SETUP.md                          # Setup instructions
├── PROJECT_STRUCTURE.md              # This file
│
├── app/                              # Next.js App Router directory
│   ├── layout.js                     # Root layout
│   ├── page.js                       # Home page (redirects to dashboard)
│   ├── globals.css                   # Global styles with Tailwind
│   │
│   ├── dashboard/                    # Dashboard pages
│   │   ├── layout.js                 # Dashboard layout with sidebar
│   │   ├── page.js                   # Dashboard page wrapper
│   │   └── DashboardContent.jsx      # Dashboard content component
│   │
│   ├── automation/                   # Platform automation pages
│   │   ├── AutomationPageClient.jsx  # Shared automation page component
│   │   ├── x/
│   │   │   └── page.js              # X (Twitter) automation page
│   │   ├── reddit/
│   │   │   └── page.js              # Reddit automation page
│   │   └── quora/
│   │       └── page.js              # Quora automation page
│   │
│   └── api/                          # API routes
│       ├── test-post/
│       │   └── route.js             # Test post endpoint
│       ├── save-settings/
│       │   └── route.js             # Save automation settings
│       ├── get-status/
│       │   └── route.js             # Get all tasks status
│       ├── get-settings/
│       │   └── route.js             # Get platform settings
│       ├── get-logs/
│       │   └── route.js             # Get activity logs
│       └── generate-content/
│           └── route.js             # Generate AI content
│
├── bot/                              # Playwright automation bots
│   ├── run.js                        # Main bot runner
│   ├── x.js                          # X (Twitter) bot
│   ├── reddit.js                     # Reddit bot
│   └── quora.js                      # Quora bot
│
├── components/                       # React components
│   ├── Sidebar.jsx                   # Navigation sidebar
│   ├── StatusCard.jsx                # Task status card
│   └── ui/                           # shadcn/ui components
│       ├── badge.jsx
│       ├── button.jsx
│       ├── card.jsx
│       ├── input.jsx
│       ├── label.jsx
│       ├── select.jsx
│       ├── switch.jsx
│       └── textarea.jsx
│
├── lib/                              # Utility libraries
│   ├── supabaseClient.js            # Supabase client and helpers
│   ├── encryption.js                 # Encryption/decryption utilities
│   └── gemini.js                     # Google Gemini AI integration
│
├── scripts/                          # Utility scripts
│   ├── setup-credentials.js          # Store encrypted credentials
│   └── test-bot.js                   # Test individual bots
│
└── supabase/                         # Supabase configuration
    ├── schema.sql                    # Database schema
    └── functions/                    # Edge functions
        └── poster/
            └── index.ts              # CRON job edge function
```

## Key Components

### Frontend (Next.js App Router)

- **App Directory**: Uses Next.js 14 App Router for routing
- **Layouts**: Root layout and dashboard layout with sidebar
- **Pages**: Dashboard, platform automation pages
- **Components**: Reusable UI components built with shadcn/ui
- **Styling**: Tailwind CSS with custom design tokens

### Backend (API Routes)

- **test-post**: Runs a bot immediately for testing
- **save-settings**: Saves platform automation configuration
- **get-status**: Retrieves status of all tasks
- **get-settings**: Gets settings for a specific platform
- **get-logs**: Retrieves activity logs
- **generate-content**: Generates content using Gemini AI

### Bot System (Playwright)

- **run.js**: Main entry point for bot execution
  - Fetches credentials from Supabase
  - Generates content with Gemini
  - Calls platform-specific bot
  
- **x.js**: X (Twitter) automation
  - Login flow
  - Tweet composition and posting
  
- **reddit.js**: Reddit automation
  - Login flow
  - Post creation in subreddits
  
- **quora.js**: Quora automation
  - Login flow
  - Answer posting on questions

### Database (Supabase)

**Tables:**
- `tasks`: Stores automation configuration
- `logs`: Activity and error logging
- `credentials`: Encrypted platform credentials

**Edge Function:**
- `poster`: Runs on CRON schedule to trigger bots

### Utilities

- **supabaseClient.js**: Database operations and helpers
- **encryption.js**: AES-256 encryption for credentials
- **gemini.js**: AI content generation with platform optimization

## Data Flow

### Manual Test Post
1. User clicks "Test Post Now"
2. Frontend calls `/api/test-post`
3. API calls `runBot()` with settings
4. Bot fetches credentials and generates content
5. Bot executes Playwright automation
6. Result logged to database and returned

### Scheduled Post (CRON)
1. Supabase CRON triggers edge function every N minutes
2. Edge function queries enabled tasks due for posting
3. Edge function calls app's `/api/test-post` for each task
4. Bot executes as in manual flow
5. Edge function updates task run times
6. Activity logged to database

### Settings Management
1. User configures settings on platform page
2. Frontend calls `/api/save-settings`
3. Settings stored in `tasks` table
4. Next run time calculated based on frequency
5. CRON picks up task when due

## Technology Stack Summary

- **Frontend Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + shadcn/ui
- **Database**: Supabase (PostgreSQL)
- **Authentication**: None (add as needed)
- **Automation**: Playwright
- **AI**: Google Gemini API
- **Encryption**: Node.js crypto (AES-256-CBC)
- **Scheduling**: Supabase Edge Functions + pg_cron
- **Deployment**: Vercel (frontend), Supabase (backend)

## File Count

- JavaScript/JSX files: 40+
- Components: 10+
- API routes: 6
- Bot scripts: 4
- Utility libraries: 3
- Configuration files: 6
- Documentation files: 3
