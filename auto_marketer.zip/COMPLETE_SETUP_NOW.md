# 🎯 Complete Your Setup - Final Steps

## ✅ What You've Already Done

✅ Supabase credentials added
✅ Gemini API key added  
✅ Encryption key generated
✅ Server is running

---

## 📋 What You Need to Do Now (3 Steps)

### Step 1: Create Database Tables in Supabase

1. Go to your Supabase project: https://supabase.com/dashboard/project/nradagxytzvvqupcsqam

2. Click **SQL Editor** in the left sidebar

3. Open the file `supabase/schema.sql` in your project folder

4. Copy ALL the contents (entire file)

5. Paste into the Supabase SQL Editor

6. Click the **RUN** button (or press Ctrl+Enter)

7. You should see: **"Success. No rows returned"**

✅ This creates 3 tables: `tasks`, `logs`, and `credentials`

---

### Step 2: Add Your Social Media Credentials

You need to add your actual social media login credentials to the `.env` file.

**Edit `.env` and replace these lines:**

```bash
# Current (placeholder values):
X_USERNAME=your-x-username
X_PASSWORD=your-x-password
REDDIT_USERNAME=your-reddit-username
REDDIT_PASSWORD=your-reddit-password
QUORA_EMAIL=your-quora-email
QUORA_PASSWORD=your-quora-password

# Replace with your actual credentials:
X_USERNAME=your_actual_twitter_username
X_PASSWORD=your_actual_twitter_password
REDDIT_USERNAME=your_actual_reddit_username
REDDIT_PASSWORD=your_actual_reddit_password
QUORA_EMAIL=your_actual_quora_email@example.com
QUORA_PASSWORD=your_actual_quora_password
```

**Important Notes:**
- Use your actual account credentials
- For X: Use your username (without @)
- For Reddit: Use your username (not email)
- For Quora: Use your email address
- Keep these credentials secure and private

---

### Step 3: Encrypt and Store Credentials

After editing `.env` with your social media credentials, run:

```bash
node scripts/setup-credentials.js
```

This will:
- Encrypt your passwords using AES-256 encryption
- Store them securely in your Supabase database
- You should see: ✅ Successfully stored X credentials, etc.

---

### Step 4: Restart the Server

```bash
# Stop the current server (Ctrl+C in your terminal)

# Then restart it:
npm run dev
```

---

## 🧪 Test That Everything Works

### Test 1: Visit Dashboard
Open: http://localhost:3000/dashboard

Should show the dashboard with no Supabase errors

### Test 2: Visit Platform Page
Open: http://localhost:3000/automation/x

Should show the X automation configuration page

### Test 3: Test AI Content Generation
```bash
curl -X POST http://localhost:3000/api/generate-content \
  -H "Content-Type: application/json" \
  -d '{"platform":"x","prompt_template":"Write a tweet about coding"}'
```

Should return AI-generated content

### Test 4: Test Full Bot (Optional - this will actually post!)
```bash
node scripts/test-bot.js x "Write a motivational tweet about learning to code"
```

⚠️ **Warning:** This will actually post to your X (Twitter) account!

---

## 🔍 Verify Your Setup

Run this command to check if everything is configured:

```bash
node scripts/verify-setup.js
```

You should see all green checkmarks ✅

---

## ❓ Troubleshooting

### "Table 'tasks' does not exist"
- You need to run `supabase/schema.sql` in Supabase SQL Editor (Step 1)

### "No credentials found for platform"
- Make sure you added your real social media credentials to `.env`
- Run `node scripts/setup-credentials.js` again

### Bot login fails
- Check your username/password are correct
- Some platforms need app-specific passwords if you have 2FA
- Try logging in manually to verify credentials work

### "Invalid credentials" from bot
- Twitter: Use username without @
- Reddit: Use username not email
- Quora: Use email not username

---

## 📊 Setup Progress

- [x] Install dependencies
- [x] Configure Supabase
- [x] Configure Gemini API
- [x] Generate encryption key
- [ ] Create database tables (Step 1)
- [ ] Add social media credentials (Step 2)
- [ ] Run setup-credentials.js (Step 3)
- [ ] Restart server (Step 4)
- [ ] Test the application

---

## 🎉 After Completion

Once you complete these steps, you'll be able to:

✅ View the dashboard with real-time bot status
✅ Configure automation for each platform
✅ Generate AI content with Gemini
✅ Test posts manually
✅ Schedule automated posting
✅ Monitor activity logs

---

## 🚀 Quick Commands Reference

```bash
# Create database tables
# → Go to Supabase SQL Editor and run schema.sql

# Store encrypted credentials
node scripts/setup-credentials.js

# Restart server
npm run dev

# Verify setup
node scripts/verify-setup.js

# Test a bot
node scripts/test-bot.js x "Your prompt here"
```

---

You're almost there! Just complete the 4 steps above and your AutoMarketer will be fully functional! 🎯
