/**
 * X (Twitter) Bot using Official API
 * Much more reliable than browser automation
 */

import { TwitterApi } from 'twitter-api-v2';
import { decrypt } from '../lib/encryption.js';

export async function runXBotAPI(settings) {
  const { content, credentials } = settings;
  
  if (!credentials || !credentials.encrypted_credentials) {
    throw new Error('X credentials not found');
  }

  const decryptedCreds = JSON.parse(decrypt(credentials.encrypted_credentials));
  const { apiKey, apiSecret, accessToken, accessSecret } = decryptedCreds;

  console.log('Starting X (Twitter) API bot...');

  try {
    // Initialize Twitter API client
    const client = new TwitterApi({
      appKey: apiKey,
      appSecret: apiSecret,
      accessToken: accessToken,
      accessSecret: accessSecret,
    });

    // Post tweet
    console.log('Posting tweet...');
    const tweet = await client.v2.tweet(content);
    
    console.log('Tweet posted successfully!');
    console.log('Tweet ID:', tweet.data.id);

    return {
      success: true,
      message: 'Tweet posted successfully via API',
      content: content,
      tweetId: tweet.data.id,
      url: `https://twitter.com/i/web/status/${tweet.data.id}`
    };

  } catch (error) {
    console.error('Error in X API bot:', error);
    throw error;
  }
}
