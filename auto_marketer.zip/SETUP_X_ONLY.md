# 🚀 Setup X (Twitter) Bot - Quick Start

## ✅ What You've Done

✅ Supabase credentials configured
✅ Gemini API key configured
✅ Encryption key set
✅ X (Twitter) username & password added

---

## 📋 Next Steps (2 Steps)

### Step 1: Create Database Tables in Supabase

**Go to your Supabase project:**
https://supabase.com/dashboard/project/nradagxytzvvqupcsqam

**Click "SQL Editor" → Then run this SQL:**

```sql
-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform TEXT NOT NULL UNIQUE,
  prompt_template TEXT NOT NULL,
  frequency_minutes INTEGER NOT NULL DEFAULT 120,
  is_enabled BOOLEAN NOT NULL DEFAULT false,
  last_run TIMESTAMP WITH TIME ZONE,
  next_run TIMESTAMP WITH TIME ZONE,
  additional_settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create logs table
CREATE TABLE IF NOT EXISTS logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'info',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create credentials table
CREATE TABLE IF NOT EXISTS credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform TEXT NOT NULL UNIQUE,
  encrypted_credentials TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tasks_platform ON tasks(platform);
CREATE INDEX IF NOT EXISTS idx_tasks_is_enabled ON tasks(is_enabled);
CREATE INDEX IF NOT EXISTS idx_tasks_next_run ON tasks(next_run);
CREATE INDEX IF NOT EXISTS idx_logs_task_id ON logs(task_id);
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_credentials_platform ON credentials(platform);

-- Enable Row Level Security
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE credentials ENABLE ROW LEVEL SECURITY;

-- Create policies (allow all for now)
CREATE POLICY "Allow all operations on tasks" ON tasks FOR ALL USING (true);
CREATE POLICY "Allow all operations on logs" ON logs FOR ALL USING (true);
CREATE POLICY "Allow all operations on credentials" ON credentials FOR ALL USING (true);

-- Function to update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_credentials_updated_at BEFORE UPDATE ON credentials
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

**You should see:** "Success. No rows returned"

---

### Step 2: Store X Credentials Securely

Run this command in your terminal:

```bash
node scripts/setup-credentials.js
```

**Expected output:**
```
Setting up platform credentials...

✅ Successfully stored X credentials
⚠️  Skipping REDDIT: Missing credentials in .env
⚠️  Skipping QUORA: Missing credentials in .env

✨ Credential setup complete!
```

This encrypts your X password and stores it in Supabase.

---

## 🧪 Test Your Setup

### Test 1: Verify Configuration
```bash
node scripts/verify-setup.js
```

### Test 2: Test AI Content Generation
```bash
curl -X POST http://localhost:3000/api/generate-content \
  -H "Content-Type: application/json" \
  -d '{"platform":"x","prompt_template":"Write a motivational tweet about coding"}'
```

You should get AI-generated content back!

### Test 3: Test the Full X Bot
```bash
node scripts/test-bot.js x "Write a tweet about learning new skills"
```

⚠️ **This will actually post to your X account!**

---

## 🎮 Use the Web Interface

1. **Restart your server** (if not already running):
   ```bash
   npm run dev
   ```

2. **Open the X automation page:**
   ```
   http://localhost:3000/automation/x
   ```

3. **Configure your automation:**
   - Toggle "Enable Automation" ON
   - Set posting frequency (e.g., every 2 hours)
   - Write your prompt template:
     ```
     Write an engaging tweet about [TOPIC]. Include relevant hashtags.
     ```
   - Click "Test Post Now" to test
   - Click "Save Settings" to enable automation

4. **Monitor in Dashboard:**
   ```
   http://localhost:3000/dashboard
   ```
   - See bot status
   - View activity logs
   - Check next scheduled run

---

## 📊 What Happens Next

Once configured:
- ✅ Bot will post to X automatically based on your frequency
- ✅ AI generates unique content each time using Gemini
- ✅ All activity is logged in the dashboard
- ✅ You can enable/disable anytime
- ✅ You can test manually before automating

---

## 🎯 Quick Commands

```bash
# Store X credentials
node scripts/setup-credentials.js

# Verify setup
node scripts/verify-setup.js

# Test X bot
node scripts/test-bot.js x "Your prompt here"

# Start server
npm run dev

# View dashboard
# http://localhost:3000/dashboard
```

---

## ✨ You're Almost There!

Just complete the 2 steps above and you'll have a working X automation bot! 🚀

After that works, you can add Reddit and Quora credentials later.
