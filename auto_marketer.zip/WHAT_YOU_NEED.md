# 🎯 What You Need to Make AutoMarketer Work

## ✅ Already Complete (Done!)

✅ All 50+ files created
✅ Dependencies installed (npm packages)
✅ Server running on http://localhost:3000
✅ Frontend UI built
✅ API endpoints ready
✅ Bot scripts ready
✅ All code is functional (no placeholders)

---

## 📝 What You Still Need (3 Things to Configure)

### 1️⃣ **Supabase Account & Database** (5 minutes)

**What it does:** Stores automation tasks, logs, and encrypted credentials

**How to get it:**

1. Go to [https://supabase.com](https://supabase.com)
2. Click "Start your project" (free tier)
3. Sign up with GitHub/Google
4. Click "New Project"
5. Choose:
   - **Name:** automarketer
   - **Database Password:** (generate strong password)
   - **Region:** Choose closest to you
6. Click "Create new project"
7. Wait 2 minutes for database to provision

**Get your credentials:**
- Go to **Settings** → **API**
- Copy these 3 values:
  - **Project URL:** `https://xxxxx.supabase.co`
  - **anon public key:** Long string starting with `eyJ...`
  - **service_role key:** Another long string starting with `eyJ...`

**Create the database tables:**
1. In Supabase, click **SQL Editor** (left sidebar)
2. Open the file `supabase/schema.sql` from your project
3. Copy ALL the contents (entire file)
4. Paste into Supabase SQL Editor
5. Click **RUN** button
6. You should see: "Success. No rows returned"

✅ **Cost:** FREE (Supabase free tier is generous)

---

### 2️⃣ **Google Gemini API Key** (2 minutes)

**What it does:** Generates AI content for your posts

**How to get it:**

1. Go to [https://makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)
2. Sign in with Google account
3. Click "Create API key"
4. Select a Google Cloud project (or create new one)
5. Click "Create API key in new project"
6. Copy the key (starts with `AIza...`)

✅ **Cost:** FREE (Gemini has generous free tier)
- Free: 60 requests per minute
- More than enough for automation

---

### 3️⃣ **Platform Credentials** (You already have these!)

**What it needs:** Your social media login credentials

**Platforms:**
- **X (Twitter):** Username + Password
- **Reddit:** Username + Password  
- **Quora:** Email + Password

✅ **Cost:** FREE (use your existing accounts)

---

## 🔧 How to Configure Everything

### Step 1: Edit `.env` File

Open the `.env` file in your project and add your credentials:

```bash
# From Supabase (Step 1 above)
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# From Google (Step 2 above)
GEMINI_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXX

# Generate this with command below
ENCRYPTION_KEY=your-32-char-random-string

# Your existing accounts (Step 3 above)
X_USERNAME=your_twitter_handle
X_PASSWORD=your_twitter_password

REDDIT_USERNAME=your_reddit_username
REDDIT_PASSWORD=your_reddit_password

QUORA_EMAIL=your_quora_email@example.com
QUORA_PASSWORD=your_quora_password

# App URL (already correct)
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

**Generate encryption key:**
```bash
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
```
Copy the output and paste it as `ENCRYPTION_KEY`

### Step 2: Store Encrypted Credentials

After editing `.env`, run:
```bash
node scripts/setup-credentials.js
```

This encrypts your social media passwords and stores them securely in Supabase.

### Step 3: Restart Server

```bash
# Stop current server (Ctrl+C)
npm run dev
```

---

## ✅ Verification Checklist

Run this to verify everything is configured:
```bash
node scripts/verify-setup.js
```

You should see all green checkmarks ✅

---

## 🚀 Test That It Works

### Test 1: Visit the Dashboard
```
http://localhost:3000/dashboard
```
Should show the dashboard with no errors

### Test 2: Test a Platform Page
```
http://localhost:3000/automation/x
```
Should load the X automation configuration page

### Test 3: Test AI Content Generation
```bash
curl -X POST http://localhost:3000/api/generate-content \
  -H "Content-Type: application/json" \
  -d '{"platform":"x","prompt_template":"Write a tweet about coding"}'
```
Should return generated content

### Test 4: Test a Bot (Full Integration)
```bash
node scripts/test-bot.js x "Write a motivational tweet about learning"
```
Should actually post to X (Twitter)

---

## 📊 Total Setup Cost

| Item | Cost | Time |
|------|------|------|
| Supabase Account | FREE | 5 min |
| Gemini API Key | FREE | 2 min |
| Platform Accounts | FREE | 0 min (you have them) |
| Configuration | FREE | 3 min |
| **TOTAL** | **$0** | **10 minutes** |

---

## 🎯 Summary: What You Need

### To Get Started:
1. ✅ **Supabase credentials** (free account)
2. ✅ **Gemini API key** (free API key)
3. ✅ **Your social media passwords** (you already have)

### To Configure:
1. Edit `.env` with the 3 items above
2. Run database schema in Supabase
3. Run `node scripts/setup-credentials.js`
4. Restart server

### Total Time: ~10 minutes
### Total Cost: $0 (everything is free tier)

---

## 🆘 Common Issues

### "Invalid Supabase URL"
- Make sure you copied the correct Project URL from Supabase
- It should start with `https://` and end with `.supabase.co`

### "GEMINI_API_KEY is not configured"
- Make sure you added the key to `.env`
- Key should start with `AIza`

### "No credentials found for platform"
- Run `node scripts/setup-credentials.js` after editing `.env`
- Make sure you added your X, Reddit, Quora credentials to `.env`

### Bot login fails
- Check your username/password are correct
- Some platforms require app-specific passwords if you have 2FA enabled
- Try logging in manually to the platform first

---

## ✨ After Setup, You Can:

✅ Post to X (Twitter) automatically
✅ Post to Reddit automatically
✅ Answer Quora questions automatically
✅ Generate AI content with Gemini
✅ Schedule posts with custom frequency
✅ Monitor all activity in dashboard
✅ View logs and errors
✅ Test posts manually before automating

---

## 🎁 Everything Else is Already Done!

The entire application is built and ready. You just need to:
1. Get free API credentials (10 minutes)
2. Add them to `.env`
3. Run setup script
4. Start using it!

**No coding required. No additional costs. Just configuration!** 🚀
