import { NextResponse } from 'next/server';
import { supabase, upsertTask } from '@/lib/supabaseClient';

export async function POST(request) {
  try {
    const body = await request.json();
    const { platform, is_enabled, frequency_minutes, prompt_template, additional_settings } = body;

    if (!platform || !prompt_template) {
      return NextResponse.json(
        { error: 'Platform and prompt_template are required' },
        { status: 400 }
      );
    }

    // Check if task exists
    const { data: existingTask } = await supabase
      .from('tasks')
      .select('id')
      .eq('platform', platform)
      .single();

    const taskData = {
      platform,
      is_enabled: is_enabled || false,
      frequency_minutes: frequency_minutes || 120,
      prompt_template,
      additional_settings: additional_settings || {},
      updated_at: new Date().toISOString()
    };

    if (existingTask) {
      taskData.id = existingTask.id;
    } else {
      taskData.created_at = new Date().toISOString();
    }

    // Calculate next run if enabled
    if (is_enabled) {
      const nextRun = new Date();
      nextRun.setMinutes(nextRun.getMinutes() + (frequency_minutes || 120));
      taskData.next_run = nextRun.toISOString();
    } else {
      taskData.next_run = null;
    }

    const task = await upsertTask(taskData);

    return NextResponse.json({
      success: true,
      message: 'Settings saved successfully',
      task
    });

  } catch (error) {
    console.error('Error saving settings:', error);
    
    return NextResponse.json(
      { error: error.message || 'Failed to save settings' },
      { status: 500 }
    );
  }
}
