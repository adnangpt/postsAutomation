import { NextResponse } from 'next/server';
import { getTasks } from '@/lib/supabaseClient';

export async function GET(request) {
  try {
    const tasks = await getTasks();

    return NextResponse.json({
      success: true,
      tasks
    });

  } catch (error) {
    console.error('Error getting status:', error);
    
    return NextResponse.json(
      { error: error.message || 'Failed to get status' },
      { status: 500 }
    );
  }
}
