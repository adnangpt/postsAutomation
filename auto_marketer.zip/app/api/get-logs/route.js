import { NextResponse } from 'next/server';
import { getLogs } from '@/lib/supabaseClient';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const taskId = searchParams.get('taskId');
    const limit = parseInt(searchParams.get('limit') || '100');

    const logs = await getLogs(taskId, limit);

    return NextResponse.json({
      success: true,
      logs
    });

  } catch (error) {
    console.error('Error getting logs:', error);
    
    return NextResponse.json(
      { error: error.message || 'Failed to get logs' },
      { status: 500 }
    );
  }
}
