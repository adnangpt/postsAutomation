import { NextResponse } from 'next/server';
import { runBot } from '@/bot/run.js';
import { createLog } from '@/lib/supabaseClient';

export async function POST(request) {
  try {
    const body = await request.json();
    const { platform, prompt_template, additional_settings } = body;

    if (!platform || !prompt_template) {
      return NextResponse.json(
        { error: 'Platform and prompt_template are required' },
        { status: 400 }
      );
    }

    // Run the bot
    const result = await runBot({
      platform,
      prompt_template,
      additional_settings: additional_settings || {}
    });

    // Log the test
    await createLog(null, `Test post successful on ${platform}`, 'info');

    return NextResponse.json({
      success: true,
      message: `Test post completed successfully on ${platform}!`,
      result
    });

  } catch (error) {
    console.error('Error in test-post:', error);
    
    return NextResponse.json(
      { 
        error: error.message || 'Failed to run test post',
        details: error.stack
      },
      { status: 500 }
    );
  }
}
