import { NextResponse } from 'next/server';
import { generateContentWithRetry } from '@/lib/gemini';

export async function POST(request) {
  try {
    const body = await request.json();
    const { prompt_template, platform } = body;

    if (!prompt_template || !platform) {
      return NextResponse.json(
        { error: 'prompt_template and platform are required' },
        { status: 400 }
      );
    }

    const content = await generateContentWithRetry(prompt_template, platform);

    return NextResponse.json({
      success: true,
      content
    });

  } catch (error) {
    console.error('Error generating content:', error);
    
    return NextResponse.json(
      { error: error.message || 'Failed to generate content' },
      { status: 500 }
    );
  }
}
