import AutomationPageClient from '../AutomationPageClient';

export default function XAutomationPage() {
  return (
    <AutomationPageClient 
      platform="x"
      title="X (Twitter) Automation"
      description="Configure automated posting to X (Twitter)"
      defaultPrompt="Write an engaging tweet about [topic]. Keep it under 280 characters and include relevant hashtags."
    />
  );
}
