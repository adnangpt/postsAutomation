# AutoMarketer Setup Guide

This guide will walk you through setting up the AutoMarketer project from scratch.

## Step 1: Install Dependencies

```bash
npm install
npx playwright install chromium
```

## Step 2: Set Up Supabase

1. Go to [https://supabase.com](https://supabase.com) and create a new project
2. Wait for the database to be provisioned
3. Go to **Project Settings** → **API** and copy:
   - Project URL
   - `anon` `public` key
   - `service_role` `secret` key

4. Go to **SQL Editor** and run the contents of `supabase/schema.sql` to create tables

## Step 3: Get Google Gemini API Key

1. Go to [https://makersuite.google.com/app/apikey](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Copy the key

## Step 4: Configure Environment Variables

1. Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

2. Fill in all the values in `.env`:
   - Supabase credentials from Step 2
   - Gemini API key from Step 3
   - Generate a random 32-character string for `ENCRYPTION_KEY`:
     ```bash
     node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
     ```
   - Add your X, Reddit, and Quora credentials

## Step 5: Store Encrypted Credentials

Run the setup script to encrypt and store platform credentials in Supabase:

```bash
node scripts/setup-credentials.js
```

This will:
- Encrypt your platform credentials
- Store them securely in the Supabase `credentials` table

## Step 6: Start the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Step 7: Configure Automation

1. Navigate to each platform page (X, Reddit, Quora)
2. Configure the settings:
   - Enable/disable automation
   - Set posting frequency
   - Write a prompt template
   - Add platform-specific settings
3. Test with "Test Post Now" button
4. Save settings

## Step 8: Deploy Supabase Edge Function (Optional)

For automated scheduling, deploy the Supabase Edge Function:

1. Install Supabase CLI:
```bash
npm install -g supabase
```

2. Login to Supabase:
```bash
supabase login
```

3. Link your project:
```bash
supabase link --project-ref your-project-ref
```

4. Deploy the edge function:
```bash
supabase functions deploy poster
```

5. Set environment variables for the edge function:
```bash
supabase secrets set APP_URL=https://your-app-url.com
```

6. Set up CRON in Supabase dashboard:

Go to **Database** → **Extensions** and enable `pg_cron` and `pg_net`.

Then run this SQL:

```sql
-- Schedule the edge function to run every 5 minutes
SELECT cron.schedule(
  'automarketer-poster',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url:='https://your-project-ref.supabase.co/functions/v1/poster',
    headers:=jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer YOUR_SERVICE_ROLE_KEY'
    )
  ) AS request_id;
  $$
);
```

Replace `your-project-ref` and `YOUR_SERVICE_ROLE_KEY` with your actual values.

## Step 9: Test Everything

### Test individual bots:
```bash
node scripts/test-bot.js x "Write a tweet about productivity"
node scripts/test-bot.js reddit "Write a post about AI"
node scripts/test-bot.js quora "Answer: What is machine learning?"
```

### Test the API:
```bash
curl -X POST http://localhost:3000/api/test-post \
  -H "Content-Type: application/json" \
  -d '{
    "platform": "x",
    "prompt_template": "Write a tweet about technology"
  }'
```

## Troubleshooting

### Playwright Issues
If bots aren't working:
1. Run with `headless: false` to see what's happening
2. Check if platform websites have changed their structure
3. Update selectors in bot files

### Supabase Connection Issues
- Verify your URL and keys are correct
- Check RLS policies allow operations
- Ensure tables are created properly

### Gemini API Issues
- Check your API key is valid
- Verify you haven't exceeded quotas
- Test the API directly

## Production Deployment

### Deploy to Vercel:

1. Push your code to GitHub
2. Import to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

### Important Security Notes:
- Never commit `.env` file
- Use proper RLS policies in Supabase
- Rotate credentials regularly
- Monitor bot activity for unusual patterns
- Respect platform rate limits and ToS

## Support

For issues and questions:
- Check the README.md for documentation
- Review error logs in the dashboard
- Check Supabase logs for edge function issues
- Review bot error screenshots
