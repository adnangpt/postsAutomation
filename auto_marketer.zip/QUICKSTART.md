# AutoMarketer Quick Start

Get up and running in 5 minutes!

## Prerequisites

- Node.js 18+ installed
- A Supabase account
- A Google Gemini API key

## Quick Setup

### 1. Install Dependencies (2 minutes)

```bash
npm install
npx playwright install chromium
```

### 2. Configure Environment (1 minute)

Edit the `.env` file and set these required values:

```bash
# Get these from supabase.com → Your Project → Settings → API
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxx...
SUPABASE_SERVICE_ROLE_KEY=eyJxxx...

# Get this from makersuite.google.com/app/apikey
GEMINI_API_KEY=AIzxxx...

# Generate with: node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
ENCRYPTION_KEY=your-random-32-char-string

# Your platform credentials
X_USERNAME=your-twitter-username
X_PASSWORD=your-twitter-password
REDDIT_USERNAME=your-reddit-username
REDDIT_PASSWORD=your-reddit-password
QUORA_EMAIL=your-quora-email
QUORA_PASSWORD=your-quora-password
```

### 3. Setup Database (1 minute)

1. Go to your Supabase project → SQL Editor
2. Copy and paste the entire contents of `supabase/schema.sql`
3. Click "Run"

### 4. Store Credentials (30 seconds)

```bash
node scripts/setup-credentials.js
```

### 5. Start the App (30 seconds)

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Usage

### Test a Single Bot

```bash
# Test X (Twitter)
node scripts/test-bot.js x "Write a motivational tweet about coding"

# Test Reddit
node scripts/test-bot.js reddit "Write a post about web development"

# Test Quora
node scripts/test-bot.js quora "Write an answer about AI"
```

### Configure Automation

1. Go to a platform page (e.g., `/automation/x`)
2. Toggle "Enable Automation" on
3. Set posting frequency
4. Write your prompt template
5. Click "Test Post Now" to verify
6. Click "Save Settings"

### Monitor Activity

Visit the Dashboard at `/dashboard` to see:
- Status of all bots
- Last and next run times
- Recent activity logs
- Errors and alerts

## Troubleshooting

### "Module not found" errors
```bash
npm install
```

### Bot login fails
- Check your credentials in `.env`
- Run with headless: false to see what's happening
- Update selectors if platform changed their UI

### Supabase connection fails
- Verify your URL and keys
- Check if tables were created (run schema.sql)
- Ensure RLS policies allow operations

### Gemini API errors
- Verify your API key
- Check you haven't exceeded quotas

## Next Steps

- Read `SETUP.md` for detailed setup instructions
- Read `README.md` for full documentation
- Set up automated scheduling with Supabase Edge Functions (see SETUP.md Step 8)
- Deploy to Vercel for production

## Support

- Check error logs in the dashboard
- Review bot error screenshots (*.png files)
- See `PROJECT_STRUCTURE.md` for architecture overview

Enjoy automating your social media! 🚀
